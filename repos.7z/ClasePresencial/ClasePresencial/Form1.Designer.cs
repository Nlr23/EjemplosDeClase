﻿namespace ClasePresencial
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEspada = new System.Windows.Forms.Button();
            this.btnArco = new System.Windows.Forms.Button();
            this.btnHacha = new System.Windows.Forms.Button();
            this.btnPistola = new System.Windows.Forms.Button();
            this.lblAccion = new System.Windows.Forms.Label();
            this.lblArmaEquipada = new System.Windows.Forms.Label();
            this.btnAtacar = new System.Windows.Forms.Button();
            this.btnCuchillo = new System.Windows.Forms.Button();
            this.btnMapa = new System.Windows.Forms.Button();
            this.btnEscudo = new System.Windows.Forms.Button();
            this.btnPota = new System.Windows.Forms.Button();
            this.btnUsar = new System.Windows.Forms.Button();
            this.lblItemActual = new System.Windows.Forms.Label();
            this.lblUso = new System.Windows.Forms.Label();
            this.btnCuchilloAt = new System.Windows.Forms.Button();
            this.btnHachaT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEspada
            // 
            this.btnEspada.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnEspada.Location = new System.Drawing.Point(80, 102);
            this.btnEspada.Name = "btnEspada";
            this.btnEspada.Size = new System.Drawing.Size(184, 59);
            this.btnEspada.TabIndex = 0;
            this.btnEspada.Text = "Espada";
            this.btnEspada.UseVisualStyleBackColor = false;
            this.btnEspada.Click += new System.EventHandler(this.btnEspada_Click);
            // 
            // btnArco
            // 
            this.btnArco.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnArco.Location = new System.Drawing.Point(80, 167);
            this.btnArco.Name = "btnArco";
            this.btnArco.Size = new System.Drawing.Size(184, 59);
            this.btnArco.TabIndex = 1;
            this.btnArco.Text = "Arco";
            this.btnArco.UseVisualStyleBackColor = false;
            this.btnArco.Click += new System.EventHandler(this.btnArco_Click);
            // 
            // btnHacha
            // 
            this.btnHacha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnHacha.Location = new System.Drawing.Point(80, 232);
            this.btnHacha.Name = "btnHacha";
            this.btnHacha.Size = new System.Drawing.Size(184, 59);
            this.btnHacha.TabIndex = 2;
            this.btnHacha.Text = "Hacha";
            this.btnHacha.UseVisualStyleBackColor = false;
            this.btnHacha.Click += new System.EventHandler(this.btnHacha_Click);
            // 
            // btnPistola
            // 
            this.btnPistola.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnPistola.Location = new System.Drawing.Point(80, 297);
            this.btnPistola.Name = "btnPistola";
            this.btnPistola.Size = new System.Drawing.Size(184, 59);
            this.btnPistola.TabIndex = 3;
            this.btnPistola.Text = "Pistola";
            this.btnPistola.UseVisualStyleBackColor = false;
            this.btnPistola.Click += new System.EventHandler(this.btnPistola_Click);
            // 
            // lblAccion
            // 
            this.lblAccion.AutoSize = true;
            this.lblAccion.Location = new System.Drawing.Point(362, 54);
            this.lblAccion.Name = "lblAccion";
            this.lblAccion.Size = new System.Drawing.Size(128, 17);
            this.lblAccion.TabIndex = 4;
            this.lblAccion.Text = "------------------------";
            // 
            // lblArmaEquipada
            // 
            this.lblArmaEquipada.AutoSize = true;
            this.lblArmaEquipada.Location = new System.Drawing.Point(362, 118);
            this.lblArmaEquipada.Name = "lblArmaEquipada";
            this.lblArmaEquipada.Size = new System.Drawing.Size(128, 17);
            this.lblArmaEquipada.TabIndex = 5;
            this.lblArmaEquipada.Text = "------------------------";
            // 
            // btnAtacar
            // 
            this.btnAtacar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAtacar.Location = new System.Drawing.Point(329, 297);
            this.btnAtacar.Name = "btnAtacar";
            this.btnAtacar.Size = new System.Drawing.Size(184, 59);
            this.btnAtacar.TabIndex = 6;
            this.btnAtacar.Text = "Ataque";
            this.btnAtacar.UseVisualStyleBackColor = false;
            this.btnAtacar.Click += new System.EventHandler(this.btnAtacar_Click);
            // 
            // btnCuchillo
            // 
            this.btnCuchillo.BackColor = System.Drawing.Color.Green;
            this.btnCuchillo.Location = new System.Drawing.Point(570, 297);
            this.btnCuchillo.Name = "btnCuchillo";
            this.btnCuchillo.Size = new System.Drawing.Size(184, 59);
            this.btnCuchillo.TabIndex = 10;
            this.btnCuchillo.Text = "Cuchillo";
            this.btnCuchillo.UseVisualStyleBackColor = false;
            this.btnCuchillo.Click += new System.EventHandler(this.btnCuchillo_Click);
            // 
            // btnMapa
            // 
            this.btnMapa.BackColor = System.Drawing.Color.Green;
            this.btnMapa.Location = new System.Drawing.Point(570, 232);
            this.btnMapa.Name = "btnMapa";
            this.btnMapa.Size = new System.Drawing.Size(184, 59);
            this.btnMapa.TabIndex = 9;
            this.btnMapa.Text = "Mapa";
            this.btnMapa.UseVisualStyleBackColor = false;
            this.btnMapa.Click += new System.EventHandler(this.btnMapa_Click);
            // 
            // btnEscudo
            // 
            this.btnEscudo.BackColor = System.Drawing.Color.Green;
            this.btnEscudo.Location = new System.Drawing.Point(570, 167);
            this.btnEscudo.Name = "btnEscudo";
            this.btnEscudo.Size = new System.Drawing.Size(184, 59);
            this.btnEscudo.TabIndex = 8;
            this.btnEscudo.Text = "Escudo";
            this.btnEscudo.UseVisualStyleBackColor = false;
            this.btnEscudo.Click += new System.EventHandler(this.btnEscudo_Click);
            // 
            // btnPota
            // 
            this.btnPota.BackColor = System.Drawing.Color.Green;
            this.btnPota.Location = new System.Drawing.Point(570, 102);
            this.btnPota.Name = "btnPota";
            this.btnPota.Size = new System.Drawing.Size(184, 59);
            this.btnPota.TabIndex = 7;
            this.btnPota.Text = "Pota";
            this.btnPota.UseVisualStyleBackColor = false;
            this.btnPota.Click += new System.EventHandler(this.btnPota_Click);
            // 
            // btnUsar
            // 
            this.btnUsar.BackColor = System.Drawing.Color.Green;
            this.btnUsar.Location = new System.Drawing.Point(329, 362);
            this.btnUsar.Name = "btnUsar";
            this.btnUsar.Size = new System.Drawing.Size(184, 59);
            this.btnUsar.TabIndex = 11;
            this.btnUsar.Text = "Usar";
            this.btnUsar.UseVisualStyleBackColor = false;
            this.btnUsar.Click += new System.EventHandler(this.btnUsar_Click);
            // 
            // lblItemActual
            // 
            this.lblItemActual.AutoSize = true;
            this.lblItemActual.Location = new System.Drawing.Point(362, 181);
            this.lblItemActual.Name = "lblItemActual";
            this.lblItemActual.Size = new System.Drawing.Size(128, 17);
            this.lblItemActual.TabIndex = 12;
            this.lblItemActual.Text = "------------------------";
            // 
            // lblUso
            // 
            this.lblUso.AutoSize = true;
            this.lblUso.Location = new System.Drawing.Point(362, 253);
            this.lblUso.Name = "lblUso";
            this.lblUso.Size = new System.Drawing.Size(128, 17);
            this.lblUso.TabIndex = 13;
            this.lblUso.Text = "------------------------";
            // 
            // btnCuchilloAt
            // 
            this.btnCuchilloAt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCuchilloAt.Location = new System.Drawing.Point(80, 362);
            this.btnCuchilloAt.Name = "btnCuchilloAt";
            this.btnCuchilloAt.Size = new System.Drawing.Size(184, 59);
            this.btnCuchilloAt.TabIndex = 14;
            this.btnCuchilloAt.Text = "Cuchillo";
            this.btnCuchilloAt.UseVisualStyleBackColor = false;
            this.btnCuchilloAt.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnHachaT
            // 
            this.btnHachaT.BackColor = System.Drawing.Color.Green;
            this.btnHachaT.Location = new System.Drawing.Point(570, 362);
            this.btnHachaT.Name = "btnHachaT";
            this.btnHachaT.Size = new System.Drawing.Size(184, 59);
            this.btnHachaT.TabIndex = 15;
            this.btnHachaT.Text = "Hacha";
            this.btnHachaT.UseVisualStyleBackColor = false;
            this.btnHachaT.Click += new System.EventHandler(this.btnHachaT_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1029, 510);
            this.Controls.Add(this.btnHachaT);
            this.Controls.Add(this.btnCuchilloAt);
            this.Controls.Add(this.lblUso);
            this.Controls.Add(this.lblItemActual);
            this.Controls.Add(this.btnUsar);
            this.Controls.Add(this.btnCuchillo);
            this.Controls.Add(this.btnMapa);
            this.Controls.Add(this.btnEscudo);
            this.Controls.Add(this.btnPota);
            this.Controls.Add(this.btnAtacar);
            this.Controls.Add(this.lblArmaEquipada);
            this.Controls.Add(this.lblAccion);
            this.Controls.Add(this.btnPistola);
            this.Controls.Add(this.btnHacha);
            this.Controls.Add(this.btnArco);
            this.Controls.Add(this.btnEspada);
            this.Font = new System.Drawing.Font("Liberation Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnEspada;
        private Button btnArco;
        private Button btnHacha;
        private Button btnPistola;
        private Label lblAccion;
        private Label lblArmaEquipada;
        private Button btnAtacar;
        private Button btnCuchillo;
        private Button btnMapa;
        private Button btnEscudo;
        private Button btnPota;
        private Button btnUsar;
        private Label lblItemActual;
        private Label lblUso;
        private Button btnCuchilloAt;
        private Button btnHachaT;
    }
}